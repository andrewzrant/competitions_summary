There are couple of things that will make the processing of your issue faster:

* Use labels to categorize your issue,
* Make sure that you are using the latest version of the master branch of the open solution,
* In case it is a bug issue, it would be nice to provide more technical details or python script that reproduces your error.

Thanks!

minerva.ml Team

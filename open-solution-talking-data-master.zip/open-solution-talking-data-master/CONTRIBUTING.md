# Contributing to the [TalkingData](https://www.kaggle.com/c/talkingdata-adtracking-fraud-detection) open solution
You are very welcome to contribute your piece to this code. There are three main ways to do so:
1. Use GitHub issues to report bugs or feature requests,
2. Create Pull Request,
3. In case of custom ideas, contact contributors directly.

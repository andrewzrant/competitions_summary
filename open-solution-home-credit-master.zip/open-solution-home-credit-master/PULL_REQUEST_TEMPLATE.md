## Pull Request template to [Home Credit Default Risk](https://www.kaggle.com/c/home-credit-default-risk) Open Solution

### Code contributions
Major - and most appreciated - contribution is pull request with feature or bug fix. Each pull request initiates discussion about your code contribution.

Each pull request should be provided with minimal description about its contents.
#

Thanks!

Jakub & Kamil,

_core contributors to the minerva.ml_
